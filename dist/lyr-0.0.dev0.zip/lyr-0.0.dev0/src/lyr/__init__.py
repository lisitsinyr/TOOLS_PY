import os

from typing import IO, TYPE_CHECKING, Any, Callable, Optional, Union

#-------------------------------------------------------------------------------
#
#-------------------------------------------------------------------------------
def main ():
#beginfunction
    print("Hello, **World**")
#endfunction

#------------------------------------------
#
#------------------------------------------
#beginmodule
if __name__ == "__main__":
    main()
#endif

#endmodule
